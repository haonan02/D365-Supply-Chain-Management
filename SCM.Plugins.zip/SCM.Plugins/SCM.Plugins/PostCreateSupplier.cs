﻿using Microsoft.Xrm.Sdk;
using System;

namespace SCM.Plugins
{
    public class PostCreateSupplier : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            // 1. 标准起手式 (获取上下文和服务)
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            // 2. 检查是否是 Create 操作，且有 Target
            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
            {
                // 注意：Create 操作的 Target 是 Entity，不是 EntityReference
                Entity supplierEntity = (Entity)context.InputParameters["Target"];

                try
                {
                    // 3. 准备要创建的 Task 数据
                    Entity followupTask = new Entity("task");

                    // 4. 设置任务标题
                    // 尝试获取供应商名字，如果没有就叫"新供应商"
                    string supplierName = supplierEntity.Attributes.Contains("scm_name") ? supplierEntity["scm_name"].ToString() : "新供应商";
                    followupTask["subject"] = $"请核查资质：{supplierName}";

                    // 5. 设置任务描述
                    followupTask["description"] = "系统自动创建的任务，请尽快联系供应商索要营业执照。";

                    // 6. 【核心】设置“关于”(Regarding) —— 把任务挂在供应商底下
                    // context.OutputParameters["id"] 是刚创建成功的供应商 ID
                    Guid newSupplierId = (Guid)context.OutputParameters["id"];
                    followupTask["regardingobjectid"] = new EntityReference("scm_supplier", newSupplierId);

                    // 7. 执行创建
                    service.Create(followupTask);
                }
                catch (Exception ex)
                {
                    throw new InvalidPluginExecutionException($"自动创建任务失败: {ex.Message}");
                }
            }
        }
    }
}